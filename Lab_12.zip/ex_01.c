#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h>

// void listf(int n, ...)
// {
// 	va_list list;
// 	va_arg

// }

typedef double (*func_ptr_t)(double x);

void show(func_ptr_t func)
{
	for (int i = 1; i < 10; i++)
	{
		printf("%lf ", func(i));
	}
	printf("\n");
}

int main(void)
{
	func_ptr_t funcs[] = {&sin, &cos, &exp, &log10, &sqrt, &fabs};

	for (int i = 0; i < 6; i++)
	{
		show(funcs[i]);
	}
	
	return 0;
}