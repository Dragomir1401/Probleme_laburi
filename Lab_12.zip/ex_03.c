#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h>
#include <string.h>

typedef int (*cmp_t)(const void*, const void*);

typedef char byte_t;

typedef struct image {
	char *name;
	int size_x;
	int size_y;
	int isRgb;
} image;

void bsort(void *v, int n, int size, cmp_t cmp)
{
	for (int i = 0; i < n; ++i) {
		for (int j = i + 1; j < n; ++j) {
			// cine e ste v[i]?
			// unde incepe?
			// "v[0]" = bytes{0, 1, .., size - 1}
			// "v[1]" = bytes{size, size + 1, .., 2 * size - 1}
			// "v[i]" = bytes{i * size, i * size + 1, .., (i + 1) * size - 1}
			//     "v[i]"": start_i = i * size
			//           end_i   = start_i + size - 1;
			// Elementul i este format din bytes dintre start_i si end_i

			// vi 00000000 00000010 00000000 00000011
			// vj 00001000 00000000 00000000 00010000

			// vi 00001000 00000000 00000000 00010000
			// vj 00000000 00000010 00000000 00000011

			// vi 00000001
			// vj 00010000

			if (cmp(v + i * size, v + j * size) > 0) { // if "v[i] > v[j]""
				// "v[i] <-> v[j]"
				byte_t *vi = v + i * size;
				byte_t *vj = v + j * size;
				for (int b = 0; b < size; ++b) {
					byte_t tmp = vi[b];
					vi[b] = vj[b];
					vj[b] = tmp;
				}
			}
		}
	}
}

int cmp_int(const void* first, const void* second) {
	int f = *(int *) first;
	int s = *(int *) second;

	if (f < s) {
		return -1;
	}
	if (f > s) {
		return +1;
	}
	return 0;
}

int cmp_char(const void* first, const void* second) {
    char f = *(char *) first;
    char s = *(char *) second;

    if (f < s) {
        return -1;
    }
    if (f > s) {
        return +1;
    }
    return 0;
}

int cmp_string(const void* first, const void* second)
{
	char *f = *(char **) first;
    char *s = *(char **) second;

	return strcmp(f, s);
}

int cmp_image(const void* first, const void* second)
{
	image f = *(image *) first;
	image s = *(image *) second;

	return strcmp(f.name, s.name);
}

int main(void)
{
	int v[10] = { 1, 4, 5, 3, 2, 8, 9, 10, 11, 15};
	bsort(v, 10, sizeof(int), cmp_int);

	char v_c[6] = {"bdasm"};
	bsort(v_c, 6, sizeof(char), cmp_char);

	char *v_s[2] = {"Robert", "Grancsa"};
	bsort(v_s, 2, sizeof(char *), cmp_string);

	image img[3] = {{"poza_grup", 32, 32, 1}, {"imagine", 4, 6, 0}, {"poza", 10, 15, 1}};
	bsort(img, 3, sizeof(img[0]), cmp_image);

	for (int i = 0; i < 10; i++)
	{
		printf("%d ", v[i]);
	}
	printf("\n");

	for (int i = 0; i < 6; i++)
	{
		printf("%c ", v_c[i]);
	}
	printf("\n");

	for (int i = 0; i < 2; i++)
	{
		printf("%s ", v_s[i]);
	}
	printf("\n");

	for (int i = 0; i < 3; i++)
	{
		printf("%s %d %d %d\n", img[i].name, img[i].size_x, img[i].size_y, img[i].isRgb);
	}

	int key = 5;
	int *pItem = (int*) bsearch (&key, v,10, sizeof (int), cmp_int);

	if (pItem)
		printf ("%d is in the array.\n", *pItem);
	else
		printf ("%d nu exista. Doesn't exist.\n",key);

	key = 6;
	pItem = (int*) bsearch (&key, v,10, sizeof (int), cmp_int);

	if (pItem)
		printf ("%d is in the array.\n", *pItem);
	else
		printf ("%d nu exista. Doesn't exist.\n",key);
	
	return 0;
}