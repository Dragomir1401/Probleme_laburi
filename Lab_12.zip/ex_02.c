#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h>

int gcd_scad(int a, int b)
{
	// if (a == b)
	// {
	// 	return a;
	// } 
	// else if(a > b)
	// {
	// 	return gcd_scad(a-b, b);
	// }
	// else 
	// {
	// 	return gcd_scad(a, b-a);
	// }
	while (a != b)
	{
		if (a > b)
			a = a - b;
		else 
			b = b - a;
	}
	return a;
}

int listf(int n, ...)
{
	if (n < 0) {
		return -1;
	}

	va_list list;
	va_start(list, n);

	int current_param = n;
	int gcd = n;
	do {
		gcd = gcd_scad(current_param, gcd);

		current_param = va_arg(list, int);
		printf("%d ", current_param);
		// fflush(stdout);

	} while (current_param >= 0);

	va_end(list);
	return gcd;
}

int main(void)
{
	printf("%d\n", listf(5, 10, -1));

	printf("%d\n", listf(5, 10, 2, 100, -1));

	printf("%d\n", listf(500, 10, 25, 75, -1));

	printf("%d\n", listf(1024, 48, 64, 256, 2048, -1));

	return 0;
}