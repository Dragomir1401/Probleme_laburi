#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h>
#include <string.h>

int bprint(FILE *fisier, char *format, ...)
{
	va_list string;
	va_start(string, format);

	while (*format != '\0') {
		if (*format == '%') {
			format++;

			if (*format == 'd') {
				int i = va_arg(string, int);
				fwrite(&i, sizeof(int), 1, fisier);
			} else if (*format == 'c') {
				char i = va_arg(string, int);
				fwrite(&i, sizeof(char), 1, fisier);
			} else if (*format == 's') {
				char *s = va_arg(string, char *);
				int size = strlen(s) + 1;
				for (int i = 0; i < size; i++) {
					fwrite(&s[i], sizeof(char), 1, fisier);
				}
			}
		}

		format++;
	}
	
	va_end(string);
	
	return 1;
}

int bscanf(FILE *fisier, char *format, ...)
{
	va_list string;
	va_start(string, format);

	while (*format != '\0') {
		if (*format == '%') {
			format++;

			if (*format == 'd') {
				int *i = va_arg(string, int *);
				fread(i, sizeof(int), 1, fisier);
				// printf("%d ", i);
			} else if (*format == 'c') {
				char *i = va_arg(string, char *);
				fread(i, sizeof(char), 1, fisier);
				// printf("%c ", i);
			} else if (*format == 's') {
				int i = 0;
				char *s = va_arg(string, char *);
				// int size = strlen(s) + 1;

				while (s[i] != '\0') {
					fread(&s[i], sizeof(char), 1, fisier);
					i++;
				}
				fread(&s[i], sizeof(char), 1, fisier);

				// printf("%s ", s);
			}
		}

		format++;
	}
	
	va_end(string);
	
	return 1;
}

int main(void)
{
	FILE * fisier = fopen("binar.bin", "wb");
	int nume_1 = 10;
	char nume_2 = 65;
	char *nume_3 = "Salut";


	bprint(fisier, "%s %d %c", nume_3, nume_1, nume_2);
	fclose(fisier);

	int nume_4 = 0;
	char nume_5 = 0;
	char *nume_6 = malloc(10000);

	fisier = fopen("binar.bin", "rb");

	bscanf(fisier, "%s %d %c", nume_6, &nume_4, &nume_5);

	printf("%s %d %c\n", nume_6, nume_4, nume_5);

	return 0;
}